import React from 'react';
import './App.css';
import ToDoList from './TodoList/ToDoList';

function App() {
  return (
    <div className="App">
      {/* <Main/> */}
       <ToDoList />
      {/* <Board/> */}

    </div>
  );
}

export default App;
